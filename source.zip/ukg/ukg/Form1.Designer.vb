﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbAlphanum = New System.Windows.Forms.RadioButton()
        Me.rbNumber = New System.Windows.Forms.RadioButton()
        Me.rbAlpha = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtMask = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.chkLower = New System.Windows.Forms.CheckBox()
        Me.chkUpper = New System.Windows.Forms.CheckBox()
        Me.numCount = New System.Windows.Forms.NumericUpDown()
        Me.btnGen = New System.Windows.Forms.Button()
        Me.txtDump = New System.Windows.Forms.TextBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnExport = New System.Windows.Forms.Button()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.numCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.ukg.My.Resources.Resources.header
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(389, 160)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbAlphanum)
        Me.GroupBox1.Controls.Add(Me.rbNumber)
        Me.GroupBox1.Controls.Add(Me.rbAlpha)
        Me.GroupBox1.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Firebrick
        Me.GroupBox1.Location = New System.Drawing.Point(12, 179)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(389, 59)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "CHARACTER POOL"
        '
        'rbAlphanum
        '
        Me.rbAlphanum.AutoSize = True
        Me.rbAlphanum.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbAlphanum.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.rbAlphanum.Location = New System.Drawing.Point(260, 25)
        Me.rbAlphanum.Name = "rbAlphanum"
        Me.rbAlphanum.Size = New System.Drawing.Size(116, 18)
        Me.rbAlphanum.TabIndex = 4
        Me.rbAlphanum.Text = "Alpha/Numeric"
        Me.rbAlphanum.UseVisualStyleBackColor = True
        '
        'rbNumber
        '
        Me.rbNumber.AutoSize = True
        Me.rbNumber.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbNumber.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.rbNumber.Location = New System.Drawing.Point(131, 25)
        Me.rbNumber.Name = "rbNumber"
        Me.rbNumber.Size = New System.Drawing.Size(102, 18)
        Me.rbNumber.TabIndex = 3
        Me.rbNumber.Text = "Numbers 0-9"
        Me.rbNumber.UseVisualStyleBackColor = True
        '
        'rbAlpha
        '
        Me.rbAlpha.AutoSize = True
        Me.rbAlpha.Checked = True
        Me.rbAlpha.Font = New System.Drawing.Font("Consolas", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbAlpha.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.rbAlpha.Location = New System.Drawing.Point(18, 25)
        Me.rbAlpha.Name = "rbAlpha"
        Me.rbAlpha.Size = New System.Drawing.Size(88, 18)
        Me.rbAlpha.TabIndex = 2
        Me.rbAlpha.TabStop = True
        Me.rbAlpha.Text = "Alpha A-Z"
        Me.rbAlpha.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtMask)
        Me.GroupBox2.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Firebrick
        Me.GroupBox2.Location = New System.Drawing.Point(12, 244)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(389, 67)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "PATTERN MASK"
        '
        'txtMask
        '
        Me.txtMask.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.txtMask.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtMask.Font = New System.Drawing.Font("Consolas", 9.75!)
        Me.txtMask.ForeColor = System.Drawing.Color.Black
        Me.txtMask.Location = New System.Drawing.Point(16, 25)
        Me.txtMask.Name = "txtMask"
        Me.txtMask.Size = New System.Drawing.Size(358, 23)
        Me.txtMask.TabIndex = 0
        Me.txtMask.Text = "XXXXX-XXXXX-XXXXX"
        Me.txtMask.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.chkLower)
        Me.GroupBox3.Controls.Add(Me.chkUpper)
        Me.GroupBox3.Controls.Add(Me.numCount)
        Me.GroupBox3.Controls.Add(Me.btnGen)
        Me.GroupBox3.Controls.Add(Me.txtDump)
        Me.GroupBox3.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.ForeColor = System.Drawing.Color.Firebrick
        Me.GroupBox3.Location = New System.Drawing.Point(12, 317)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(389, 199)
        Me.GroupBox3.TabIndex = 6
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "GENERATE"
        '
        'chkLower
        '
        Me.chkLower.AutoSize = True
        Me.chkLower.Font = New System.Drawing.Font("Consolas", 9.75!)
        Me.chkLower.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.chkLower.Location = New System.Drawing.Point(274, 161)
        Me.chkLower.Name = "chkLower"
        Me.chkLower.Size = New System.Drawing.Size(89, 19)
        Me.chkLower.TabIndex = 4
        Me.chkLower.Text = "Lowercase"
        Me.chkLower.UseVisualStyleBackColor = True
        '
        'chkUpper
        '
        Me.chkUpper.AutoSize = True
        Me.chkUpper.Checked = True
        Me.chkUpper.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUpper.Font = New System.Drawing.Font("Consolas", 9.75!)
        Me.chkUpper.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.chkUpper.Location = New System.Drawing.Point(179, 161)
        Me.chkUpper.Name = "chkUpper"
        Me.chkUpper.Size = New System.Drawing.Size(89, 19)
        Me.chkUpper.TabIndex = 3
        Me.chkUpper.Text = "Uppercase"
        Me.chkUpper.UseVisualStyleBackColor = True
        '
        'numCount
        '
        Me.numCount.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.numCount.Font = New System.Drawing.Font("Consolas", 9.75!)
        Me.numCount.Location = New System.Drawing.Point(16, 159)
        Me.numCount.Maximum = New Decimal(New Integer() {-727379969, 232, 0, 0})
        Me.numCount.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numCount.Name = "numCount"
        Me.numCount.Size = New System.Drawing.Size(76, 23)
        Me.numCount.TabIndex = 2
        Me.numCount.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'btnGen
        '
        Me.btnGen.BackColor = System.Drawing.SystemColors.Control
        Me.btnGen.Font = New System.Drawing.Font("Consolas", 8.75!)
        Me.btnGen.ForeColor = System.Drawing.Color.Black
        Me.btnGen.Location = New System.Drawing.Point(98, 159)
        Me.btnGen.Name = "btnGen"
        Me.btnGen.Size = New System.Drawing.Size(75, 24)
        Me.btnGen.TabIndex = 1
        Me.btnGen.Text = "Generate"
        Me.btnGen.UseVisualStyleBackColor = False
        '
        'txtDump
        '
        Me.txtDump.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.txtDump.Font = New System.Drawing.Font("Consolas", 9.75!)
        Me.txtDump.ForeColor = System.Drawing.Color.Black
        Me.txtDump.Location = New System.Drawing.Point(16, 24)
        Me.txtDump.Multiline = True
        Me.txtDump.Name = "txtDump"
        Me.txtDump.ReadOnly = True
        Me.txtDump.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtDump.Size = New System.Drawing.Size(358, 129)
        Me.txtDump.TabIndex = 0
        Me.txtDump.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtDump.WordWrap = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.btnExport)
        Me.GroupBox4.Font = New System.Drawing.Font("Consolas", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Firebrick
        Me.GroupBox4.Location = New System.Drawing.Point(12, 522)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(389, 67)
        Me.GroupBox4.TabIndex = 6
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "EXPORT"
        '
        'btnExport
        '
        Me.btnExport.BackColor = System.Drawing.SystemColors.Control
        Me.btnExport.Font = New System.Drawing.Font("Consolas", 8.75!)
        Me.btnExport.ForeColor = System.Drawing.Color.Black
        Me.btnExport.Location = New System.Drawing.Point(16, 24)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(358, 26)
        Me.btnExport.TabIndex = 5
        Me.btnExport.Text = "DUMP LIST TO TEXT FILE"
        Me.btnExport.UseVisualStyleBackColor = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.ActiveLinkColor = System.Drawing.Color.Red
        Me.LinkLabel1.Font = New System.Drawing.Font("Consolas", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.LinkColor = System.Drawing.Color.WhiteSmoke
        Me.LinkLabel1.Location = New System.Drawing.Point(12, 592)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(389, 39)
        Me.LinkLabel1.TabIndex = 7
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "github.com/waived"
        Me.LinkLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.LinkLabel1.VisitedLinkColor = System.Drawing.Color.WhiteSmoke
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(413, 641)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Font = New System.Drawing.Font("Consolas", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "/// Universal Key Generator ///       github.com/waived"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.numCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbAlphanum As RadioButton
    Friend WithEvents rbNumber As RadioButton
    Friend WithEvents rbAlpha As RadioButton
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtMask As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents chkLower As CheckBox
    Friend WithEvents chkUpper As CheckBox
    Friend WithEvents numCount As NumericUpDown
    Friend WithEvents btnGen As Button
    Friend WithEvents txtDump As TextBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents btnExport As Button
    Friend WithEvents LinkLabel1 As LinkLabel
End Class
