﻿Public Class Form1
    Public _pool() As Char

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

#Region "form handling junk"
    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("https://github.com/waived")
    End Sub

    Private Sub chkUpper_CheckedChanged(sender As Object, e As EventArgs) Handles chkUpper.CheckedChanged
        If chkUpper.Checked = True Then
            chkLower.Checked = False
        ElseIf chkUpper.Checked = False Then
            chkLower.Checked = True
        End If
    End Sub

    Private Sub chkLower_CheckedChanged(sender As Object, e As EventArgs) Handles chkLower.CheckedChanged
        If chkLower.Checked = True Then
            chkUpper.Checked = False
        ElseIf chkLower.Checked = False Then
            chkUpper.Checked = True
        End If
    End Sub
#End Region

#Region "ghetto software-key generation"
    Private Sub btnGen_Click(sender As Object, e As EventArgs) Handles btnGen.Click

        If Not String.IsNullOrEmpty(txtMask.Text) Then

            If chkUpper.Checked = True Then
                txtDump.CharacterCasing = CharacterCasing.Upper
            Else
                txtDump.CharacterCasing = CharacterCasing.Lower
            End If

            If rbAlpha.Checked = True Then
                _pool = "ABCDEFGHIJKLOMNOPQRSTUVWXYZ".ToCharArray()
            ElseIf rbNumber.Checked = True Then
                _pool = "0123456789".ToCharArray()
            ElseIf rbAlphanum.Checked = True Then
                _pool = "ABCDEFGHIJKLOMNOPQRSTUVWXYZ0123456789".ToCharArray()
            End If

            btnGen.Enabled = False
            btnExport.Enabled = False
            txtMask.ReadOnly = True
            chkUpper.Enabled = False
            chkLower.Enabled = False
            rbAlpha.Enabled = False
            rbAlphanum.Enabled = False
            rbNumber.Enabled = False

            txtDump.Clear()
            System.Threading.ThreadPool.QueueUserWorkItem(Sub() _genKeys())
        End If
    End Sub

    Private Sub _genKeys()
        Me.CheckForIllegalCrossThreadCalls = False
        Dim _max As Integer = numCount.Value

        Dim i As Integer = 0
        Do Until i = _max
            Dim key As String

            For Each ch As Char In txtMask.Text
                If ch.ToString = "X" Then
                    key += genJunk(1)
                Else
                    key += ch.ToString
                End If
            Next
            txtDump.Text = txtDump.Text + key + vbNewLine

            key = ""
            i += 1
        Loop

        ' clean-up UI
        btnGen.Enabled = True
        btnExport.Enabled = True
        txtMask.ReadOnly = False
        txtMask.Text = "XXXXX-XXXXX-XXXXX"
        chkUpper.Enabled = True
        chkUpper.Checked = True
        chkLower.Enabled = True
        rbAlpha.Enabled = True
        rbAlphanum.Enabled = True
        rbNumber.Enabled = True
        rbAlpha.Checked = True
    End Sub

    Public Function genJunk(_len As Integer) As String
        Static rnd As New Random()
        Dim res As String = ""
        For i As Integer = 1 To _len
            res += _pool(rnd.Next(1, _pool.Length))
        Next
        Return res
    End Function

    Private Sub btnExport_Click(sender As Object, e As EventArgs) Handles btnExport.Click
        _export()
    End Sub

    Private Sub _export()
        Me.CheckForIllegalCrossThreadCalls = False

        If Not String.IsNullOrEmpty(txtDump.Text) Then
            Dim sfd As SaveFileDialog = New SaveFileDialog
            sfd.FileName = "keys.txt"
            sfd.Filter = "Text Files|*.txt"

            If sfd.ShowDialog = DialogResult.OK Then
                Try
                    Dim file As System.IO.StreamWriter
                    file = My.Computer.FileSystem.OpenTextFileWriter(sfd.FileName, True)
                    file.WriteLine(txtDump.Text)
                    file.Close()
                    MessageBox.Show("Key(s) exported successfully!", "Alert!")
                Catch ex As Exception
                    MessageBox.Show("Critical error encountered!", "Alert!")
                End Try
            End If
        End If
    End Sub
#End Region
End Class
